
const BusinessConnect = () => {
    return (
        <div>

        </div>
    );
};

export default BusinessConnect;