import { FaBeer } from 'react-icons/fa';
import { Link, Element } from 'react-scroll';
import Navbar from './Components/Navbar';

function App() {

  return (
    <>
    <div className="bg-slate-900">    
     <Navbar/>
    </div>
    </>
  )
}

export default App
