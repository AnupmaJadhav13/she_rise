import React from 'react';
import { Link } from 'react-scroll';

const Navbar = () => {
    const content =<>
    <div className="">
        <ul className="">
            <Link to='Home'>
            <li>Home</li>
            </Link>
            <Link to="About">
            <li>About</li>
            </Link>
            <Link to="MentorConnect">
            <li>MentorConnect</li>
            </Link>
            <Link   to="BusinessConnect">
            <li>BusinessConnect</li>
            </Link>

        </ul>
        </div></>
    return (
        <navbar>
            <div className="h-10vh flex justify-between z-50 text-white lg:py-5 px-20 py-4 flex-1">
                <div className="flex items-center flex-1">
                    <span className='text-3xl font-bold'>Logo</span>
                </div>
                <div className="lg:flex md:flex lg: flex-1 items-center justify-end font-normal">
                    <div>
                        <ul className="flex gap-8 mr-16 text-[18px]">
            <Link to='Home'>
            <li>Home</li>
            </Link>
            <Link to="About">
            <li>About</li>
            </Link>
            <Link to="MentorConnect">
            <li>MentorConnect</li>
            </Link>
            <Link   to="BusinessConnect">
            <li>BusinessConnect</li>
            </Link>

        </ul>
                    </div>
                </div>
            </div>

        </navbar>
    );
};

export default Navbar;